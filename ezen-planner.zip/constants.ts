
export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
