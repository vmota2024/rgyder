import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_TEXT_MODEL } from '../constants';

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error("A API_KEY para o Gemini não está configurada nas variáveis de ambiente. As funcionalidades de IA não funcionarão.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "CHAVE_API_AUSENTE" });

interface AIServiceErrorParams {
  message: string;
  cause?: unknown;
  details?: Record<string, unknown>;
}

class AIServiceError extends Error {
  public cause?: unknown;
  public details?: Record<string, unknown>;

  constructor({ message, cause, details }: AIServiceErrorParams) {
    super(message);
    this.name = "AIServiceError";
    this.cause = cause;
    this.details = details;
  }
}

const parseJsonFromText = <T,>(text: string): T | null => {
  let jsonStr = text.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Falha ao analisar resposta JSON:", e, "Texto original:", text);
    throw new AIServiceError({
        message: "A IA retornou um formato JSON inválido.",
        cause: e,
        details: { originalText: text }
    });
  }
};


export const generateCaptionAndHashtags = async (
  topic: string
): Promise<{ caption: string; hashtags: string[] }> => {
  if (!apiKey) {
    throw new AIServiceError({ message: "A Chave de API para o Gemini não está configurada. Não é possível gerar conteúdo." });
  }

  try {
    // Etapa 1: Gerar Legenda
    const captionPrompt = `Gere uma legenda de Instagram envolvente e concisa em português do Brasil para um post sobre "${topic}". Inclua emojis relevantes. A legenda deve ser adequada para um público geral.`;
    
    const captionResponse: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: captionPrompt,
    });
    const generatedCaption = captionResponse.text.trim();

    if (!generatedCaption) {
      throw new AIServiceError({ message: "A IA falhou ao gerar uma legenda." });
    }

    // Etapa 2: Gerar Hashtags com base na legenda gerada
    const hashtagsPrompt = `Com base na seguinte legenda do Instagram em português do Brasil, sugira de 5 a 7 hashtags relevantes e populares. Retorne sua resposta como um array JSON de strings. Por exemplo: ["#viagem", "#aventura", "#fotografia"]. Legenda: "${generatedCaption}"`;

    const hashtagsResponse: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_TEXT_MODEL,
        contents: hashtagsPrompt,
        config: {
            responseMimeType: "application/json",
        }
    });
    
    const hashtagsText = hashtagsResponse.text;
    if (!hashtagsText) {
        throw new AIServiceError({ message: "A IA falhou ao gerar hashtags." });
    }

    const parsedHashtags = parseJsonFromText<string[]>(hashtagsText);
    if (!parsedHashtags || !Array.isArray(parsedHashtags)) {
        throw new AIServiceError({ message: "A IA retornou hashtags em um formato inesperado." });
    }
    
    const cleanedHashtags = parsedHashtags.map(tag => {
      let cleaned = typeof tag === 'string' ? tag.trim() : '';
      if (!cleaned.startsWith('#')) {
        cleaned = `#${cleaned}`;
      }
      return cleaned;
    }).filter(tag => tag !== '#');


    return {
      caption: generatedCaption,
      hashtags: cleanedHashtags.slice(0, 7),
    };

  } catch (error) {
    console.error("Erro ao gerar conteúdo com IA:", error);
    if (error instanceof AIServiceError) {
        throw error;
    }
    throw new AIServiceError({
        message: "Ocorreu um erro inesperado ao gerar conteúdo com IA.",
        cause: error
    });
  }
};