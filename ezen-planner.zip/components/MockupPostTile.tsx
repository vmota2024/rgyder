import React from 'react';
import { Post } from '../types';
import { ImagePlaceholderIcon, PencilIcon, VideoCameraIcon } from './Icons';

interface MockupPostTileProps {
  post: Post;
  onPostClick: (post: Post) => void;
}

const MockupPostTile: React.FC<MockupPostTileProps> = ({ post, onPostClick }) => {
  return (
    <button
      onClick={() => onPostClick(post)}
      className="relative aspect-square bg-slate-200 group focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 rounded overflow-hidden"
      aria-label={`Ver detalhes do post: ${post.topic || 'sem título'}`}
    >
      {post.imageUrl ? (
        <img src={post.imageUrl} alt={post.topic || 'Imagem do post'} className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-slate-300">
          <ImagePlaceholderIcon className="w-1/3 h-1/3 text-slate-500" />
        </div>
      )}
      {post.postType === 'video' && (
          <div className="absolute top-1.5 right-1.5 bg-black bg-opacity-60 p-1 rounded-full">
            <VideoCameraIcon className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
          </div>
        )}
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 group-focus:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
        <PencilIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 group-focus:opacity-100 transform scale-75 group-hover:scale-100 group-focus:scale-100 transition-all duration-200" />
      </div>
    </button>
  );
};

export default MockupPostTile;