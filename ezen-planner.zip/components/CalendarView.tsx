import React, { useState, useMemo } from 'react';
import { Post } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, PlusIcon, VideoCameraIcon } from './Icons';

interface CalendarViewProps {
  posts: Post[];
  onSelectDate: (date: string) => void; // Para criar um novo post nesta data
  onEditPost: (post: Post) => void;    // Para editar um post existente
}

const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const CalendarView: React.FC<CalendarViewProps> = ({ posts, onSelectDate, onEditPost }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const startOfMonth = useMemo(() => new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), [currentDate]);
  const endOfMonth = useMemo(() => new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), [currentDate]);
  const startDay = useMemo(() => startOfMonth.getDay(), [startOfMonth]); 
  const daysInMonth = useMemo(() => endOfMonth.getDate(), [endOfMonth]);

  const postsByDate = useMemo(() => {
    const map = new Map<string, Post[]>();
    posts.forEach(post => {
      if (post.scheduledDate) {
        const dateKey = post.scheduledDate; 
        if (!map.has(dateKey)) {
          map.set(dateKey, []);
        }
        map.get(dateKey)!.push(post);
      }
    });
    return map;
  }, [posts]);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const calendarCells = [];
  for (let i = 0; i < startDay; i++) {
    calendarCells.push(<div key={`empty-start-${i}`} className="border border-slate-200 p-1 sm:p-2 h-24 sm:h-32"></div>);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const dateKey = date.toISOString().split('T')[0];
    const postsForDay = postsByDate.get(dateKey) || [];
    const isToday = new Date().toISOString().split('T')[0] === dateKey;

    calendarCells.push(
      <div
        key={dateKey}
        className={`border border-slate-200 p-1 sm:p-2 h-24 sm:h-32 flex flex-col relative cursor-pointer hover:bg-slate-50 transition-colors group
          ${isToday ? 'bg-indigo-50' : ''}
        `}
        onClick={() => onSelectDate(dateKey)}
        role="gridcell"
        aria-label={`Data ${date.toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' })}, ${postsForDay.length} post(s). Clique para adicionar ou ver posts.`}
      >
        <time dateTime={dateKey} className={`text-xs sm:text-sm font-medium ${isToday ? 'text-indigo-600 font-bold' : 'text-slate-700'}`}>
          {day}
        </time>
        <div className="mt-1 space-y-0.5 sm:space-y-1 overflow-y-auto flex-grow max-h-[calc(100%-1.5rem)] no-scrollbar">
          {postsForDay.slice(0, 2).map(post => (
            <button
              key={post.id}
              onClick={(e) => { e.stopPropagation(); onEditPost(post); }}
              className={`w-full text-left text-[10px] sm:text-xs p-0.5 sm:p-1 rounded text-white hover:opacity-80 truncate transition-colors flex items-center
                ${post.postType === 'video' ? 'bg-purple-500' : 'bg-pink-500'}
              `}
              title={post.topic || post.caption.substring(0,30)}
              aria-label={`Editar post: ${post.topic || 'sem título'}`}
            >
              {post.postType === 'video' && <VideoCameraIcon className="w-3 h-3 mr-1 flex-shrink-0" />}
              <span className="truncate">{post.topic || post.caption.substring(0,15) + '...'}</span>
            </button>
          ))}
          {postsForDay.length > 2 && (
            <div className="text-[10px] sm:text-xs text-slate-500 text-center">+{postsForDay.length - 2} mais</div>
          )}
        </div>
         {(
            <button 
                onClick={(e) => { e.stopPropagation(); onSelectDate(dateKey); }}
                className="absolute bottom-1 right-1 text-slate-300 hover:text-indigo-500 p-0.5 rounded-full opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity"
                aria-label={`Adicionar post para ${date.toLocaleDateString('pt-BR')}`}
                title={`Adicionar post para ${date.toLocaleDateString('pt-BR')}`}
            >
                <PlusIcon className="w-3 h-3 sm:w-4 sm:h-4"/>
            </button>
        )}
      </div>
    );
  }
  
  const totalCells = startDay + daysInMonth;
  const remainingCells = (7 - (totalCells % 7)) % 7;
    for (let i = 0; i < remainingCells; i++) {
    calendarCells.push(<div key={`empty-end-${i}`} className="border border-slate-200 p-1 sm:p-2 h-24 sm:h-32"></div>);
  }

  return (
    <div className="bg-white p-3 sm:p-4 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-3 sm:mb-4">
        <button
          onClick={handlePrevMonth}
          className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          aria-label="Mês anterior"
        >
          <ChevronLeftIcon className="w-5 h-5 sm:w-6 sm:h-6 text-slate-600" />
        </button>
        <div className="text-center">
            <h2 className="text-lg sm:text-xl font-semibold text-slate-800">
            {startOfMonth.toLocaleString('pt-BR', { month: 'long', year: 'numeric' })}
            </h2>
            <button 
                onClick={handleToday}
                className="text-xs sm:text-sm text-indigo-600 hover:text-indigo-800 font-medium"
            >
                Hoje
            </button>
        </div>
        <button
          onClick={handleNextMonth}
          className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          aria-label="Próximo mês"
        >
          <ChevronRightIcon className="w-5 h-5 sm:w-6 sm:h-6 text-slate-600" />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-px bg-slate-200 border border-slate-200" role="grid" aria-label="Calendário mensal">
        {daysOfWeek.map(d => (
          <div key={d} className="text-center text-xs sm:text-sm font-medium text-slate-600 py-2 bg-slate-50" role="columnheader">
            {d}
          </div>
        ))}
        {calendarCells}
      </div>
    </div>
  );
};

export default CalendarView;