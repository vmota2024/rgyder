import React from 'react';
import { Post, ClientProfile, PostStatus } from '../types';
import { XMarkIcon, PencilIcon, CalendarIcon, TagIcon, ImagePlaceholderIcon, UserCircleIcon, ChatBubbleLeftEllipsisIcon, CheckCircleIcon, XCircleIcon, ExclamationTriangleIcon, ClockIcon, VideoCameraIcon } from './Icons';

interface PostDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post;
  clientProfile: ClientProfile;
  onEdit: (post: Post) => void;
}

const getStatusPill = (status: PostStatus) => {
  let bgColor = 'bg-slate-100';
  let textColor = 'text-slate-700';
  let Icon = ClockIcon;
  let statusText = 'Pendente';

  switch (status) {
    case 'Aprovado':
      bgColor = 'bg-green-100';
      textColor = 'text-green-700';
      Icon = CheckCircleIcon;
      statusText = 'Aprovado';
      break;
    case 'Rejeitado':
      bgColor = 'bg-red-100';
      textColor = 'text-red-700';
      Icon = XCircleIcon;
      statusText = 'Rejeitado';
      break;
    case 'Revisar':
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-700';
      Icon = ExclamationTriangleIcon;
      statusText = 'Revisar';
      break;
    case 'Pendente':
      statusText = 'Pendente';
      break;
  }
  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${bgColor} ${textColor}`}>
      <Icon className="w-4 h-4 mr-1.5" />
      {statusText}
    </span>
  );
};


const PostDetailModal: React.FC<PostDetailModalProps> = ({ isOpen, onClose, post, clientProfile, onEdit }) => {
  if (!isOpen) return null;

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Não agendado';
    try {
      const date = new Date(dateString.includes('T') ? dateString : dateString + 'T00:00:00');
      return date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch (e) { return 'Data Inválida'; }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-md flex items-center justify-center p-4 z-[120] overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby={`post-detail-title-${post.id}`}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[95vh] flex flex-col sm:flex-row overflow-hidden">
        {/* Seção da Imagem/Capa */}
        <div className="w-full sm:w-1/2 md:w-3/5 bg-black flex items-center justify-center relative">
          {post.imageUrl ? (
            <img src={post.imageUrl} alt={post.topic || (post.postType === 'video' ? 'Capa do vídeo' : 'Imagem do post')} className="max-h-[90vh] sm:max-h-full w-auto h-auto max-w-full object-contain" />
          ) : (
            <div className="w-full h-64 sm:h-full flex items-center justify-center bg-slate-800">
              <ImagePlaceholderIcon className="w-24 h-24 text-slate-500" />
            </div>
          )}
          {post.postType === 'video' && (
            <div className="absolute top-3 left-3 bg-black bg-opacity-60 p-2 rounded-full">
                <VideoCameraIcon className="w-6 h-6 text-white" />
            </div>
          )}
           <button onClick={onClose} className="absolute top-3 right-3 text-white bg-black bg-opacity-50 p-2 rounded-full hover:bg-opacity-75 transition sm:hidden" aria-label="Fechar modal">
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Seção de Detalhes */}
        <div className="w-full sm:w-1/2 md:w-2/5 flex flex-col p-5 space-y-4 overflow-y-auto no-scrollbar">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-200 shrink-0">
                {clientProfile.profileImageUrl ? (
                  <img src={clientProfile.profileImageUrl} alt={clientProfile.username} className="w-full h-full object-cover" />
                ) : (
                  <UserCircleIcon className="w-full h-full text-slate-400" />
                )}
              </div>
              <div>
                <h3 id={`post-detail-title-${post.id}`} className="font-semibold text-slate-800">{clientProfile.username}</h3>
                {post.topic && <p className="text-xs text-slate-500">{post.topic}</p>}
              </div>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 hidden sm:block" aria-label="Fechar modal">
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>
          
          <div className="border-t border-slate-200 pt-3">
            <p className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
              <span className="font-semibold text-slate-800">{clientProfile.username}</span> {post.caption}
            </p>
          </div>

          {post.hashtags && post.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {post.hashtags.map((tag, index) => (
                <span key={index} className="text-indigo-600 hover:text-indigo-700 text-sm font-medium">
                  {tag.startsWith('#') ? tag : `#${tag}`}
                </span>
              ))}
            </div>
          )}
          
          <div className="space-y-3 pt-2 text-sm text-slate-600">
            {post.scheduledDate && (
              <div className="flex items-center">
                <CalendarIcon className="w-4 h-4 mr-2 text-slate-400" />
                Agendado para: <span className="font-medium ml-1">{formatDate(post.scheduledDate)}</span>
              </div>
            )}
            {post.postType === 'video' && post.videoUrl && (
                 <div className="flex items-center">
                    <VideoCameraIcon className="w-4 h-4 mr-2 text-slate-400" />
                    URL do Vídeo: <a href={post.videoUrl} target="_blank" rel="noopener noreferrer" className="font-medium ml-1 text-indigo-600 hover:underline truncate max-w-[150px] sm:max-w-full">{post.videoUrl}</a>
                </div>
            )}
             <div className="flex items-center">
                {getStatusPill(post.status)}
            </div>
            {post.feedbackComments && (
                <div className="p-2 bg-slate-50 rounded-md border border-slate-200">
                    <div className="flex items-center text-xs text-slate-500 mb-0.5 font-medium">
                        <ChatBubbleLeftEllipsisIcon className="w-3.5 h-3.5 mr-1 text-indigo-500"/> Feedback:
                    </div>
                    <p className="text-xs text-slate-600 italic whitespace-pre-wrap">{post.feedbackComments}</p>
                </div>
            )}
          </div>
          
          {clientProfile.bio && (
            <div className="pt-3 border-t border-slate-200">
                <h4 className="text-xs font-semibold text-slate-500 uppercase mb-1">Sobre {clientProfile.username}</h4>
                <p className="text-sm text-slate-600 whitespace-pre-wrap">{clientProfile.bio}</p>
            </div>
          )}

          <div className="mt-auto pt-4 border-t border-slate-200">
            <button
              onClick={() => onEdit(post)}
              className="w-full flex items-center justify-center px-4 py-2.5 border border-slate-300 text-sm font-medium rounded-md shadow-sm text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              <PencilIcon className="w-4 h-4 mr-2" />
              Editar Detalhes do Post
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostDetailModal;