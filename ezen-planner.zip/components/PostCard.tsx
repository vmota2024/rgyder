import React from 'react';
import { Post, PostStatus } from '../types';
import { PencilIcon, TrashIcon, CalendarIcon, TagIcon, ImagePlaceholderIcon, CheckCircleIcon, XCircleIcon, ExclamationTriangleIcon, ChatBubbleLeftEllipsisIcon, ClockIcon, VideoCameraIcon } from './Icons';

interface PostCardProps {
  post: Post;
  onEdit: (post: Post) => void;
  onDelete: (id: string) => void;
}

const getStatusInfo = (status: PostStatus): { text: string; color: string; bgColor: string; Icon: React.FC<React.SVGProps<SVGSVGElement>> } => {
  switch (status) {
    case 'Aprovado':
      return { text: 'Aprovado', color: 'text-green-700', bgColor: 'bg-green-100', Icon: CheckCircleIcon };
    case 'Rejeitado':
      return { text: 'Rejeitado', color: 'text-red-700', bgColor: 'bg-red-100', Icon: XCircleIcon };
    case 'Revisar':
      return { text: 'Revisar', color: 'text-yellow-700', bgColor: 'bg-yellow-100', Icon: ExclamationTriangleIcon };
    case 'Pendente':
    default:
      return { text: 'Pendente', color: 'text-slate-600', bgColor: 'bg-slate-100', Icon: ClockIcon };
  }
};

const PostCard: React.FC<PostCardProps> = ({ post, onEdit, onDelete }) => {
  const formatDate = (dateString: string) => {
    if (!dateString) return 'Não agendado';
    try {
      const date = new Date(dateString.includes('T') ? dateString : dateString + 'T00:00:00');
      return date.toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    } catch (e) {
      console.error("Erro ao formatar data:", dateString, e);
      return 'Data Inválida';
    }
  };

  const { text: statusText, color: statusColor, bgColor: statusBgColor, Icon: StatusIcon } = getStatusInfo(post.status);

  return (
    <article aria-labelledby={`post-topic-${post.id}`} className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl flex flex-col">
      <div className="relative">
        {post.imageUrl ? (
          <img src={post.imageUrl} alt={post.topic || 'Imagem do post'} className="w-full h-60 object-cover" />
        ) : (
          <div className="w-full h-60 bg-slate-200 flex items-center justify-center">
            <ImagePlaceholderIcon className="w-16 h-16 text-slate-400" />
          </div>
        )}
        {post.postType === 'video' && (
          <div className="absolute top-2 right-2 bg-black bg-opacity-50 p-1.5 rounded-full">
            <VideoCameraIcon className="w-5 h-5 text-white" />
          </div>
        )}
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-1">
          {post.topic && <h3 id={`post-topic-${post.id}`} className="text-sm text-indigo-600 font-semibold uppercase tracking-wide flex-grow pr-2">{post.topic}</h3>}
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusBgColor} ${statusColor}`}>
            <StatusIcon className="w-3.5 h-3.5 mr-1 -ml-0.5" />
            {statusText}
          </span>
        </div>
        <p className="text-slate-700 text-sm mb-3 leading-relaxed flex-grow min-h-[60px]">{post.caption || "Nenhuma legenda fornecida."}</p>
        
        {post.hashtags && post.hashtags.length > 0 && (
          <div className="mb-3">
            <div className="flex items-center text-xs text-slate-500 mb-1 font-medium">
              <TagIcon className="w-3.5 h-3.5 mr-1.5 text-pink-500"/> Hashtags:
            </div>
            <div className="flex flex-wrap gap-1.5">
              {post.hashtags.map((tag, index) => (
                <span key={index} className="bg-pink-100 text-pink-700 px-2.5 py-1 rounded-full text-xs font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {post.feedbackComments && (
          <div className="mb-3 p-2.5 bg-slate-50 rounded-md border border-slate-200">
            <div className="flex items-center text-xs text-slate-500 mb-1 font-medium">
              <ChatBubbleLeftEllipsisIcon className="w-3.5 h-3.5 mr-1.5 text-indigo-500"/> Feedback:
            </div>
            <p className="text-xs text-slate-600 italic whitespace-pre-wrap">{post.feedbackComments}</p>
          </div>
        )}

        <div className="text-xs text-slate-500 flex items-center mb-4 mt-auto pt-3">
          <CalendarIcon className="w-4 h-4 mr-2 text-indigo-400" />
          Agendado para: <span className="font-medium ml-1">{formatDate(post.scheduledDate)}</span>
        </div>
        
        <div className="mt-auto flex justify-end space-x-2 pt-4 border-t border-slate-200">
          <button
            onClick={() => onEdit(post)}
            className="text-slate-500 hover:text-indigo-600 p-2 rounded-full transition duration-150 focus:outline-none focus:ring-2 focus:ring-indigo-300"
            title="Editar Post"
            aria-label={`Editar post ${post.topic ? 'intitulado ' + post.topic : 'sem título'}`}
          >
            <PencilIcon className="w-5 h-5" />
          </button>
          <button
            onClick={() => onDelete(post.id)}
            className="text-slate-500 hover:text-red-600 p-2 rounded-full transition duration-150 focus:outline-none focus:ring-2 focus:ring-red-300"
            title="Excluir Post"
            aria-label={`Excluir post ${post.topic ? 'intitulado ' + post.topic : 'sem título'}`}
          >
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
    </article>
  );
};

export default PostCard;