import React, { useState, useEffect, useRef }  from 'react';
import { ClientProfile } from '../types';
import { XMarkIcon, UserCircleIcon, CameraIcon, TrashIcon } from './Icons';

interface ClientProfileSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (profile: ClientProfile) => void;
  currentProfile: ClientProfile;
}

const ClientProfileSettingsModal: React.FC<ClientProfileSettingsModalProps> = ({ isOpen, onClose, onSave, currentProfile }) => {
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [profileImagePreviewUrl, setProfileImagePreviewUrl] = useState<string | null>(null);
  const [currentProfileImageUrl, setCurrentProfileImageUrl] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setUsername(currentProfile.username);
      setBio(currentProfile.bio);
      setProfileImagePreviewUrl(currentProfile.profileImageUrl || null);
      setCurrentProfileImageUrl(currentProfile.profileImageUrl || '');
      setError(null);
    }
  }, [isOpen, currentProfile]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // Limite de 2MB para foto de perfil
        setError("O tamanho da imagem de perfil não deve exceder 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImagePreviewUrl(reader.result as string);
        setCurrentProfileImageUrl(reader.result as string);
        setError(null);
      };
      reader.onerror = () => setError("Falha ao ler o arquivo de imagem.");
      reader.readAsDataURL(file);
    }
  };

  const handleClearImage = () => {
    setProfileImagePreviewUrl(null);
    setCurrentProfileImageUrl('');
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
        setError('O nome de usuário não pode estar vazio.');
        return;
    }
    onSave({
      username,
      bio,
      profileImageUrl: currentProfileImageUrl,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center p-4 z-[110]" role="dialog" aria-modal="true" aria-labelledby="client-profile-title">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[95vh] flex flex-col">
        <div className="flex justify-between items-center p-5 border-b border-slate-200">
          <h2 id="client-profile-title" className="text-xl font-semibold text-slate-800">Configurações do Perfil do Cliente</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Fechar modal">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto no-scrollbar">
          {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded" role="alert"><p>{error}</p></div>}

          <div className="flex flex-col items-center space-y-3">
            <div className="relative group w-32 h-32 rounded-full overflow-hidden bg-slate-200 flex items-center justify-center">
              {profileImagePreviewUrl ? (
                <img src={profileImagePreviewUrl} alt="Pré-visualização do Perfil" className="w-full h-full object-cover" />
              ) : (
                <UserCircleIcon className="w-24 h-24 text-slate-400" />
              )}
              {profileImagePreviewUrl && (
                 <button
                    type="button"
                    onClick={handleClearImage}
                    className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    aria-label="Remover imagem de perfil"
                  >
                    <TrashIcon className="w-4 h-4" />
                  </button>
              )}
            </div>
             <input
                id="profile-image-upload"
                type="file"
                accept="image/png, image/jpeg"
                onChange={handleImageChange}
                className="sr-only"
                ref={fileInputRef}
              />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center px-3 py-1.5 border border-slate-300 text-sm font-medium rounded-md text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <CameraIcon className="w-4 h-4 mr-2 text-slate-500" />
              {profileImagePreviewUrl ? 'Alterar Foto' : 'Carregar Foto'}
            </button>
          </div>

          <div>
            <label htmlFor="username" className="block text-sm font-medium text-slate-700 mb-1">Nome de Usuário</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Ex: NomeDoSeuCliente"
              required
              className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label htmlFor="bio" className="block text-sm font-medium text-slate-700 mb-1">Bio</label>
            <textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              placeholder="Uma breve biografia para o perfil do cliente."
              className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>
          
          <div className="pt-3 flex justify-end space-x-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              Salvar Perfil
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ClientProfileSettingsModal;