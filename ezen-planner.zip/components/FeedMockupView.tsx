import React from 'react';
import { Post, ClientProfile } from '../types';
import MockupPostTile from './MockupPostTile';
import { ImagePlaceholderIcon, UserCircleIcon } from './Icons';

interface FeedMockupViewProps {
  posts: Post[];
  clientProfile: ClientProfile;
  onPostClick: (post: Post) => void;
}

const FeedMockupView: React.FC<FeedMockupViewProps> = ({ posts, clientProfile, onPostClick }) => {
  if (posts.length === 0 && clientProfile.username === 'seu_usuario') { 
    return (
      <div className="text-center py-12 flex flex-col items-center bg-white p-8 rounded-lg shadow-lg">
        <ImagePlaceholderIcon className="w-20 h-20 text-slate-300 mb-4" />
        <h2 className="text-xl font-semibold text-slate-600 mb-2">Seu Feed Parece Vazio</h2>
        <p className="text-slate-500">Adicione alguns posts e configure o perfil do seu cliente para ver o mockup do feed do Instagram!</p>
      </div>
    );
  }

  // Ordena posts por data agendada decrescente, depois por criação (id) se não houver data
  const sortedPosts = [...posts].sort((a, b) => {
    if (a.scheduledDate && b.scheduledDate) {
      return new Date(b.scheduledDate).getTime() - new Date(a.scheduledDate).getTime();
    }
    if (a.scheduledDate) return -1;
    if (b.scheduledDate) return 1;
    return parseInt(b.id) - parseInt(a.id); // Mais recentes primeiro se sem data
  });

  return (
    <div className="bg-white p-2 sm:p-4 rounded-lg shadow-lg max-w-3xl mx-auto">
        <div className="p-4 border-b border-slate-200 mb-4">
            <div className="flex items-center space-x-4">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                    {clientProfile.profileImageUrl ? (
                        <img src={clientProfile.profileImageUrl} alt={clientProfile.username} className="w-full h-full object-cover" />
                    ) : (
                        <UserCircleIcon className="w-12 h-12 sm:w-16 sm:h-16 text-slate-400"/>
                    )}
                </div>
                <div>
                    <h2 className="text-lg sm:text-xl font-semibold text-slate-800">{clientProfile.username}</h2>
                    <p className="text-sm text-slate-500">{sortedPosts.length} {sortedPosts.length === 1 ? 'publicação' : 'publicações'}</p>
                    {clientProfile.bio && <p className="text-xs text-slate-600 mt-1">{clientProfile.bio}</p>}
                </div>
            </div>
        </div>
      {sortedPosts.length > 0 ? (
        <div className="grid grid-cols-3 gap-0.5 sm:gap-1">
          {sortedPosts.map(post => (
            <MockupPostTile key={post.id} post={post} onPostClick={onPostClick} />
          ))}
        </div>
      ) : (
         <div className="text-center py-10">
            <ImagePlaceholderIcon className="w-16 h-16 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">Ainda não há posts para este feed.</p>
        </div>
      )}
    </div>
  );
};

export default FeedMockupView;