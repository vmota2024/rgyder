import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Post, PartialPost, PostStatus, PostType } from '../types';
import { generateCaptionAndHashtags } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { SparklesIcon, XMarkIcon, CameraIcon, TrashIcon, VideoCameraIcon } from './Icons'; // CanvaLogoIcon removido

interface PostFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (post: PartialPost) => void;
  initialPost?: Post;
  initialDate?: string; 
}

const postStatuses: { value: PostStatus; label: string }[] = [
  { value: 'Pendente', label: 'Pendente' },
  { value: 'Aprovado', label: 'Aprovado' },
  { value: 'Rejeitado', label: 'Rejeitado' },
  { value: 'Revisar', label: 'Revisar' },
];

const MAX_IMAGE_SIZE_MB = 5;
const MAX_VIDEO_SIZE_MB = 50; // Limite para vídeos (pode precisar ajustar)

const PostFormModal: React.FC<PostFormModalProps> = ({ isOpen, onClose, onSave, initialPost, initialDate }) => {
  const [topic, setTopic] = useState('');
  const [caption, setCaption] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const [currentImageUrl, setCurrentImageUrl] = useState<string>('');
  const [status, setStatus] = useState<PostStatus>('Pendente');
  const [feedbackComments, setFeedbackComments] = useState('');
  const [postType, setPostType] = useState<PostType>('image');
  const [uploadedVideoDataUrl, setUploadedVideoDataUrl] = useState<string | null>(null); // Para vídeo em base64

  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const imageFileInputRef = useRef<HTMLInputElement>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (initialPost) {
        setTopic(initialPost.topic);
        setCaption(initialPost.caption);
        setScheduledDate(initialPost.scheduledDate || '');
        setHashtags(initialPost.hashtags || []);
        setImagePreviewUrl(initialPost.imageUrl || null);
        setCurrentImageUrl(initialPost.imageUrl || '');
        setStatus(initialPost.status || 'Pendente');
        setFeedbackComments(initialPost.feedbackComments || '');
        setPostType(initialPost.postType || 'image');
        setUploadedVideoDataUrl(initialPost.uploadedVideoDataUrl || null);
      } else {
        setTopic('');
        setCaption('');
        setScheduledDate(initialDate || new Date().toISOString().split('T')[0]);
        setHashtags([]);
        setImagePreviewUrl(null);
        setCurrentImageUrl('');
        setStatus('Pendente');
        setFeedbackComments('');
        setPostType('image');
        setUploadedVideoDataUrl(null);
      }
      setError(null);
    }
  }, [initialPost, initialDate, isOpen]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > MAX_IMAGE_SIZE_MB * 1024 * 1024) {
        setError(`O tamanho da imagem não deve exceder ${MAX_IMAGE_SIZE_MB}MB.`);
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviewUrl(reader.result as string);
        setCurrentImageUrl(reader.result as string);
        setError(null);
      };
      reader.onerror = () => setError("Falha ao ler o arquivo de imagem.");
      reader.readAsDataURL(file);
    }
  };
  
  const handleClearImage = () => {
    setImagePreviewUrl(null);
    setCurrentImageUrl('');
    if (imageFileInputRef.current) {
        imageFileInputRef.current.value = "";
    }
  };

  const handleVideoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!['video/mp4', 'video/webm', 'video/quicktime'].includes(file.type)) {
        setError('Tipo de vídeo inválido. Use MP4, WebM ou MOV.');
        return;
      }
      if (file.size > MAX_VIDEO_SIZE_MB * 1024 * 1024) {
        setError(`O tamanho do vídeo não deve exceder ${MAX_VIDEO_SIZE_MB}MB.`);
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedVideoDataUrl(reader.result as string);
        setError(null);
      };
      reader.onerror = () => setError("Falha ao ler o arquivo de vídeo.");
      reader.readAsDataURL(file);
    }
  };

  const handleClearVideo = () => {
    setUploadedVideoDataUrl(null);
    if (videoFileInputRef.current) {
      videoFileInputRef.current.value = "";
    }
  };


  const handleGenerateContent = useCallback(async () => {
    if (!topic.trim()) {
      setError('Por favor, insira um tópico para gerar conteúdo.');
      return;
    }
    setIsGenerating(true);
    setError(null);
    try {
      const result = await generateCaptionAndHashtags(topic);
      setCaption(result.caption);
      setHashtags(result.hashtags);
    } catch (err) {
      console.error("Erro na Geração com IA:", err);
      setError(err instanceof Error ? err.message : 'Falha ao gerar conteúdo. Verifique o console para detalhes.');
    } finally {
      setIsGenerating(false);
    }
  }, [topic]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caption.trim() && !topic.trim() && !currentImageUrl && postType === 'image') {
        setError('Forneça algum conteúdo para o post (tópico, legenda ou imagem).');
        return;
    }
    if (postType === 'video' && !currentImageUrl) {
        setError('Para posts de vídeo, uma imagem de capa é obrigatória.');
        return;
    }
     if (postType === 'video' && !uploadedVideoDataUrl) {
        setError('Para posts de vídeo, um arquivo de vídeo é obrigatório.');
        return;
    }
    onSave({
      id: initialPost?.id,
      topic,
      caption: caption.trim() || (topic ? `Post sobre ${topic}` : "Post Sem Título"),
      scheduledDate,
      hashtags,
      imageUrl: currentImageUrl,
      status,
      feedbackComments,
      postType,
      uploadedVideoDataUrl: postType === 'video' ? uploadedVideoDataUrl : undefined,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center p-4 z-[100] overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="post-form-title">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[95vh] flex flex-col">
        <div className="flex justify-between items-center p-5 border-b border-slate-200">
          <h2 id="post-form-title" className="text-xl font-semibold text-slate-800">
            {initialPost ? 'Editar Post' : 'Criar Novo Post'}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Fechar modal">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto no-scrollbar">
          {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded relative mb-4" role="alert"><p className="font-bold">Erro</p><p>{error}</p></div>}
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Tipo de Post</label>
            <div className="flex space-x-4">
              <label className="flex items-center">
                <input type="radio" name="postType" value="image" checked={postType === 'image'} onChange={() => setPostType('image')} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-slate-300"/>
                <span className="ml-2 text-sm text-slate-700">Imagem</span>
              </label>
              <label className="flex items-center">
                <input type="radio" name="postType" value="video" checked={postType === 'video'} onChange={() => setPostType('video')} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-slate-300"/>
                <span className="ml-2 text-sm text-slate-700">Vídeo (Reels)</span>
              </label>
            </div>
          </div>

          <div>
            <label htmlFor="image-upload" className="block text-sm font-medium text-slate-700 mb-1">{postType === 'video' ? 'Imagem de Capa do Vídeo' : 'Imagem'}</label>
            <div className="mt-1 flex flex-col items-center p-4 border-2 border-dashed border-slate-300 rounded-md space-y-2">
              {imagePreviewUrl ? (
                <div className="relative group">
                  <img src={imagePreviewUrl} alt="Pré-visualização da capa/imagem" className="max-h-48 rounded-md object-contain" />
                  <button type="button" onClick={handleClearImage} className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remover imagem">
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="text-center">
                  <CameraIcon className="mx-auto h-12 w-12 text-slate-400" />
                  <p className="text-xs text-slate-500 mt-1">Clique para carregar ou arraste e solte</p>
                  <p className="text-xs text-slate-400">PNG, JPG, GIF até {MAX_IMAGE_SIZE_MB}MB</p>
                </div>
              )}
              <input id="image-upload" type="file" accept="image/png, image/jpeg, image/gif" onChange={handleImageChange} className="sr-only" ref={imageFileInputRef} />
              <button type="button" onClick={() => imageFileInputRef.current?.click()} className="text-sm font-medium text-indigo-600 hover:text-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                {imagePreviewUrl ? (postType === 'video' ? 'Alterar Capa' : 'Alterar Imagem') : (postType === 'video' ? 'Carregar Capa' : 'Carregar Imagem')}
              </button>
            </div>
          </div>

          {postType === 'video' && (
            <div>
                <label htmlFor="video-upload" className="block text-sm font-medium text-slate-700 mb-1">Arquivo de Vídeo</label>
                <div className="mt-1 flex flex-col items-center p-4 border-2 border-dashed border-slate-300 rounded-md space-y-2">
                  {uploadedVideoDataUrl ? (
                    <div className="relative group w-full">
                      <video src={uploadedVideoDataUrl} controls className="max-h-48 rounded-md object-contain w-full"></video>
                      <button type="button" onClick={handleClearVideo} className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remover vídeo">
                        <TrashIcon className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <VideoCameraIcon className="mx-auto h-12 w-12 text-slate-400" />
                      <p className="text-xs text-slate-500 mt-1">Clique para carregar vídeo</p>
                      <p className="text-xs text-slate-400">MP4, WebM, MOV até {MAX_VIDEO_SIZE_MB}MB</p>
                    </div>
                  )}
                  <input id="video-upload" type="file" accept="video/mp4,video/webm,video/quicktime" onChange={handleVideoChange} className="sr-only" ref={videoFileInputRef} />
                  <button type="button" onClick={() => videoFileInputRef.current?.click()} className="text-sm font-medium text-indigo-600 hover:text-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    {uploadedVideoDataUrl ? 'Alterar Vídeo' : 'Carregar Vídeo'}
                  </button>
                </div>
            </div>
          )}
          
          <div>
            <label htmlFor="topic" className="block text-sm font-medium text-slate-700 mb-1">Tópico / Palavras-chave <span className="text-slate-400 text-xs">(para geração com IA)</span></label>
            <input type="text" id="topic" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Ex: Férias de verão, lançamento de novo produto" className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>

          <button type="button" onClick={handleGenerateContent} disabled={isGenerating || !topic.trim()} className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-pink-500 hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-400 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors">
            {isGenerating ? (<><LoadingSpinner className="w-5 h-5 mr-2" /> Gerando...</>) : (<><SparklesIcon className="w-5 h-5 mr-2" /> Gerar Legenda e Hashtags</>)}
          </button>

          <div>
            <label htmlFor="caption" className="block text-sm font-medium text-slate-700 mb-1">Legenda <span className="text-slate-500 text-xs">(obrigatório se sem tópico ou imagem/capa)</span></label>
            <textarea id="caption" value={caption} onChange={(e) => setCaption(e.target.value)} rows={4} placeholder="Escreva a legenda do seu post do Instagram aqui..." className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>

          <div>
            <label htmlFor="hashtags" className="block text-sm font-medium text-slate-700 mb-1">Hashtags <span className="text-slate-400 text-xs">(separadas por vírgula)</span></label>
            <input type="text" id="hashtags" value={hashtags.join(', ')} onChange={(e) => setHashtags(e.target.value.split(',').map(h => h.trim()).filter(h => h))} placeholder="#viagem, #comida, #novopost" className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          
          <div>
            <label htmlFor="scheduledDate" className="block text-sm font-medium text-slate-700 mb-1">Data de Agendamento</label>
            <input type="date" id="scheduledDate" value={scheduledDate} min={new Date().toISOString().split('T')[0]} onChange={(e) => setScheduledDate(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>

          <div>
            <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-1">Status</label>
            <select id="status" value={status} onChange={(e) => setStatus(e.target.value as PostStatus)} className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
              {postStatuses.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>

          <div>
            <label htmlFor="feedbackComments" className="block text-sm font-medium text-slate-700 mb-1">Feedback / Comentários</label>
            <textarea id="feedbackComments" value={feedbackComments} onChange={(e) => setFeedbackComments(e.target.value)} rows={3} placeholder="Ex: Precisa de uma chamada para ação mais forte." className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          
          <div className="pt-3 flex justify-end space-x-3 border-t border-slate-200">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">Cancelar</button>
            <button type="submit" disabled={isGenerating} className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors">
              {isGenerating ? <LoadingSpinner className="w-5 h-5" /> : (initialPost ? 'Salvar Alterações' : 'Adicionar Post')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PostFormModal;