import React from 'react';
import { PlusIcon, UserCircleIcon } from './Icons';

interface HeaderProps {
  onAddPost: () => void;
  onOpenProfileSettings: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAddPost, onOpenProfileSettings }) => {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <h1 className="text-2xl sm:text-3xl font-bold">
          <span className="text-slate-800">EZEN</span><span className="text-red-600">Planner</span>
        </h1>
        <div className="flex items-center space-x-2 sm:space-x-3">
          <button
            onClick={onOpenProfileSettings}
            aria-label="Abrir configurações do perfil do cliente"
            title="Configurações do Perfil do Cliente"
            className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-100 rounded-full transition duration-150 ease-in-out"
          >
            <UserCircleIcon className="w-6 h-6 sm:w-7 sm:h-7" />
          </button>
          <button
            onClick={onAddPost}
            aria-label="Adicionar novo post"
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-3 sm:px-4 rounded-lg shadow-sm transition duration-150 ease-in-out flex items-center"
          >
            <PlusIcon className="w-5 h-5 sm:mr-2" />
            <span className="hidden sm:inline">Adicionar Post</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;