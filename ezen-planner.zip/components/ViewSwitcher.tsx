import React from 'react';
import { ViewMode } from '../types';
import { GridViewIcon, CalendarViewIcon, FeedViewIcon } from './Icons';

interface ViewSwitcherProps {
  currentView: ViewMode;
  onViewChange: (viewMode: ViewMode) => void;
}

const viewOptions: { mode: ViewMode; label: string; icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
  { mode: 'grid', label: 'Grade', icon: GridViewIcon },
  { mode: 'calendar', label: 'Calendário', icon: CalendarViewIcon },
  { mode: 'feed', label: 'Mockup do Feed', icon: FeedViewIcon },
];

const ViewSwitcher: React.FC<ViewSwitcherProps> = ({ currentView, onViewChange }) => {
  return (
    <nav className="mb-6 flex justify-center space-x-2 sm:space-x-3 p-1 bg-slate-200 rounded-lg shadow-sm" aria-label="Seleção do modo de visualização">
      {viewOptions.map(({ mode, label, icon: Icon }) => (
        <button
          key={mode}
          onClick={() => onViewChange(mode)}
          aria-pressed={currentView === mode}
          className={`flex-1 sm:flex-none flex items-center justify-center px-3 py-2 sm:px-4 sm:py-2.5 rounded-md text-xs sm:text-sm font-medium transition-colors duration-150
            ${
              currentView === mode
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-transparent text-slate-600 hover:bg-slate-300 hover:text-slate-800'
            }
          `}
        >
          <Icon className="w-4 h-4 sm:w-5 sm:h-5 mr-1.5 sm:mr-2" />
          {label}
        </button>
      ))}
    </nav>
  );
};

export default ViewSwitcher;